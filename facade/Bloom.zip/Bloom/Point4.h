﻿#pragma once

struct Point4
{
  GLfloat x;
  GLfloat y;
  GLfloat s;
  GLfloat t;
};
