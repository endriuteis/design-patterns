﻿#include "StdAfx.h"
#include "Util.h"