﻿#pragma once

class TextureManager
{
public:
  TextureManager(const char* face, unsigned font_size, Size glyph_size)
  {
    
  }
};
